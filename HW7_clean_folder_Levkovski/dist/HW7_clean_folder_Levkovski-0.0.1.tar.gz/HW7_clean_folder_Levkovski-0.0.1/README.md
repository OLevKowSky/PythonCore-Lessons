# "HW7_clean_folder_Levkovski"

## A script that parses the junk folder

### To do this, our application will check the file extension (the last characters in the file name, usually after a dot) and, depending on the extension, make a decision to which category to assign this file. The script accepts one argument at startup — the name of the folder in which it will sort. Let's say the file with the program is called sort.py, then to sort the /user/Desktop/Junk folder, you need to run the script with the python command sort.py /user/Desktop/Junk

## For running test use command "python .\HW6.py (Path)"

## Always check the style

### For style checking:

- flacke8
- pylint
  "run code_style"

## For deploy

Use command: deploy -s <environment>
