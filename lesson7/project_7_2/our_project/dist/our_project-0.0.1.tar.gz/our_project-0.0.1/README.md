# "OUR_PROJECT"

### This is very nice project

### For running test use command "run_test"

## Always check the style

### For style checking:

- flacke8
- pylint
  "run code_style"

## For deploy

Use command: deploy -s <environment>
