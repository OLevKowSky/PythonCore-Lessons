def adding(x, y):
    return x + y
    